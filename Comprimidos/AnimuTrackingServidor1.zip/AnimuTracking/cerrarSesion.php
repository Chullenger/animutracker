<?php
	session_start();
	session_destroy();
	header('Location: http://25.90.246.130:8080/');
?>